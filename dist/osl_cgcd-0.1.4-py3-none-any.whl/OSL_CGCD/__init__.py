# OSL_CGCD package initialization

__version__ = "0.1.1"

# Puedes importar aquí los módulos principales si lo deseas
# from . import modulo1
# from . import modulo2
