# OSL_CGCD package initialization

__version__ = "0.1.5"

# You can import the main module here if desired
from . import modulo
